<?php $pdo = new PDO('mysql:host=localhost; dbname=id11023501_blueocean;   
		charset = utf8', 'id11023501_blueokean', 'ciniuokean34');
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);     //Set maximum error reporting for PDO otherwise debugging will be very difficult
		