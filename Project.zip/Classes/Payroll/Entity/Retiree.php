<?php 
namespace Payroll\Entity;

class Retiree {
    
	public $id;
	public $info;


	

	public function __construct()
	{
		
		
	
	}
	
	
	
}