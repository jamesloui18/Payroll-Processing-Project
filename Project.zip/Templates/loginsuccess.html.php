<h1 style="text-align:center">  Welcome <?= $_SESSION['username'] ?> to this Great Website
<p> You are now logged in . </p></h1>