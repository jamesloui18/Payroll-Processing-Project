<?php foreach($retiree as $retired) :?> 

 <div align="left" id="nametitle"><p><?= $retired->info ?> </p></div>

<?php endforeach; ?>   