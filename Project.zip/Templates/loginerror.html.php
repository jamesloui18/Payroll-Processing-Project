<div  style= "text-align: center">
<h1> You are Not logged in 
<p> You must be logged in to view this page </p>

<p><a href = "index.php?route=login"> Click here to login in  </a> </p>
<p>or</p>
<p><a href = "index.php?route=user/register">Click here to register an account </a> </p> </h1> </div>