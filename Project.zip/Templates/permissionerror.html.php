<div class = "errors">
		<h1><p>No Permission set for user <?= $_SESSION['username']?></p>
		<p>Add Privileges by Admin</p>
	
<div>