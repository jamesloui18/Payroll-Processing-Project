<div style ="text-align:center"><h1> Logged Out 

<p>You have been logged out. Thank You. Log in again Another Day</p></h1></div>