<div style="text-align:center">
<h1> Registration Successful 
<p>Your are now registered on the BlueOcean payroll database </p>
</h1></div>
<!--<//?php if(isset($users)) :?> -->
<!-- <h1><p> Users Who are Subscribed </p></h1>
<//?php foreach($users as $user) //get the next record in result set
{ ?>

<h1> User: <//?= $user->name?>  Email: <//?= $user->email?> </h1>   <!-- entity class is helping here as the user's information can be accessed using the arrow operator, otherwise, would have to seperately send them in an array -->
<!-- <h3> password: <//?= $user->password ?></h3>

<!-- <//?php } ?>
<!-- <//?php endif; ?> 