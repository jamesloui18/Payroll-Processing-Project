<div id = "home"><div class = "BO">
	<h1> Blue Ocean: The Reliable Payroll Service
	<p>The admin will have extended privileges on the website like registering a new employee for Blue Ocean. Afterwards, the admin can press the Tax and Deductions tabs to adjust their tax and deduction rates.</p>
	<p>Each newly registered employee for Blue Ocean has an account in the system. All they have to do is register with their own password and username.</p>
	<p>Our system has standard security. Each password is hashed. So remember your password. Otherwise we can't rectify the password.</p>
	</h1></div>